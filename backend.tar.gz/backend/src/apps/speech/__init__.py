from .endpoints import router

__all__ = ["router"]
"""
MCP模块测试fixtures
"""

from .mcp_fixtures import *
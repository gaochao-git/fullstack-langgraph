"""
MCP module - MCP服务器管理模块
"""

from .endpoints import router

__all__ = ['router']
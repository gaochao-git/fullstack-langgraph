"""
IDC Research Module
IDC运行报告模块
"""

from .endpoints import router
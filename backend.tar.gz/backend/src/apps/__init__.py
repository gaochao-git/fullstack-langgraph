"""
Business applications module
"""
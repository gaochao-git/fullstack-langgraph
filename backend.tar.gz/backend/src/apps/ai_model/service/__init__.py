"""
AI Model services
"""

from .ai_model_service import AIModelService, ai_model_service

__all__ = ['AIModelService', 'ai_model_service']
"""
AI模型模块测试fixtures
"""
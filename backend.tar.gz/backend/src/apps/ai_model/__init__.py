"""
AI Model module - AI模型管理模块
"""

from .endpoints import router

__all__ = ['router']
"""
Scheduled Task module - 定时任务管理模块
"""

from .endpoints import router

__all__ = ['router']
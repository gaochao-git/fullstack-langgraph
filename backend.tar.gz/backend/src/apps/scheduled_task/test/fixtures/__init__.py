"""
定时任务模块测试fixtures
"""
"""Pydantic schemas for SOP API."""
from __future__ import annotations
from typing import List, Optional, Literal
from pydantic import BaseModel, Field
from datetime import datetime


class SOPStep(BaseModel):
    """SOP execution step schema - supports tree structure."""
    id: Optional[str] = Field(None, description="Step unique identifier", max_length=100)
    step: str = Field(..., description="Step name", min_length=1, max_length=200)
    description: str = Field(..., description="Step description", min_length=1, max_length=1000)
    execution_status: Optional[str] = Field("pending", description="Step execution status", max_length=20)
    health_status: Optional[str] = Field("unknown", description="Step health status", max_length=20)
    children: Optional[List[SOPStep]] = Field(None, description="Child steps for tree structure")
    
    class Config:
        # 允许递归模型
        arbitrary_types_allowed = True


class SOPTemplateCreate(BaseModel):
    """Schema for creating SOP template."""
    sop_id: str = Field(..., description="Unique SOP identifier", min_length=1, max_length=100, pattern=r'^[a-zA-Z0-9_-]+$')
    sop_title: str = Field(..., description="SOP title", min_length=1, max_length=500)
    sop_category: str = Field(..., description="SOP category", min_length=1, max_length=100)
    sop_description: Optional[str] = Field(None, description="SOP description", max_length=2000)
    sop_severity: Literal["low", "medium", "high", "critical"] = Field("high", description="SOP severity level")
    steps: SOPStep = Field(..., description="Root execution step with nested children")
    tools_required: Optional[List[str]] = Field(default_factory=list, description="List of required tools", max_items=20)
    sop_recommendations: str = Field("", description="SOP recommendations", max_length=2000)
    team_name: str = Field("", description="Responsible team name", max_length=100)


class SOPTemplateUpdate(BaseModel):
    """Schema for updating SOP template."""
    sop_title: Optional[str] = Field(None, description="SOP title", min_length=1, max_length=500)
    sop_category: Optional[str] = Field(None, description="SOP category", min_length=1, max_length=100)
    sop_description: Optional[str] = Field(None, description="SOP description", max_length=2000)
    sop_severity: Optional[Literal["low", "medium", "high", "critical"]] = Field(None, description="SOP severity level")
    steps: Optional[SOPStep] = Field(None, description="Root execution step with nested children")
    tools_required: Optional[List[str]] = Field(None, description="List of required tools", max_items=20)
    sop_recommendations: Optional[str] = Field(None, description="SOP recommendations", max_length=2000)
    team_name: Optional[str] = Field(None, description="Responsible team name", min_length=1, max_length=100)


class SOPTemplateResponse(BaseModel):
    """Schema for SOP template response."""
    id: int
    sop_id: str
    sop_title: str
    sop_category: str
    sop_description: Optional[str]
    sop_severity: str
    sop_steps: str  # JSON string
    tools_required: Optional[str]  # JSON string
    sop_recommendations: Optional[str]
    team_name: str
    create_by: str
    update_by: Optional[str]
    create_time: str
    update_time: str

    class Config:
        from_attributes = True


class SOPQueryParams(BaseModel):
    """Schema for SOP query parameters."""
    search: Optional[str] = Field(None, description="Search term for title, description, or ID", max_length=200)
    category: Optional[str] = Field(None, description="Filter by category", max_length=100)
    severity: Optional[Literal["low", "medium", "high", "critical"]] = Field(None, description="Filter by severity")
    team_name: Optional[str] = Field(None, description="Filter by team name", max_length=100)
    limit: Optional[int] = Field(10, description="Number of results to return", ge=1, le=100)
    offset: Optional[int] = Field(0, description="Number of results to skip", ge=0)


class SOPListResponse(BaseModel):
    """Schema for SOP list response."""
    data: List[SOPTemplateResponse]
    total: int


class ApiResponse(BaseModel):
    """Generic API response schema."""
    success: bool
    data: Optional[object] = None
    message: Optional[str] = None
    error: Optional[str] = None


# 更新前向引用以支持递归
SOPStep.model_rebuild()

# ============ SOP Problem Rule 相关模型 ============

class RuleInfo(BaseModel):
    """规则信息"""
    source_type: str = Field("zabbix", description="数据源类型")
    item_keys: List[str] = Field(..., description="监控项key列表", min_items=1)


class SOPProblemRuleBase(BaseModel):
    """SOP问题规则基础模型"""
    rule_name: str = Field(..., description="规则名称", min_length=1, max_length=200)
    sop_id: str = Field(..., description="关联的SOP ID", min_length=1, max_length=100)
    rules_info: RuleInfo = Field(..., description="规则信息")
    is_enabled: bool = Field(True, description="是否启用")


class SOPProblemRuleCreate(SOPProblemRuleBase):
    """创建SOP问题规则请求"""
    pass


class SOPProblemRuleUpdate(BaseModel):
    """更新SOP问题规则请求"""
    rule_name: Optional[str] = Field(None, description="规则名称", min_length=1, max_length=200)
    sop_id: Optional[str] = Field(None, description="关联的SOP ID", min_length=1, max_length=100)
    rules_info: Optional[RuleInfo] = Field(None, description="规则信息")
    is_enabled: Optional[bool] = Field(None, description="是否启用")


class SOPProblemRuleResponse(BaseModel):
    """SOP问题规则响应"""
    id: int
    rule_name: str
    sop_id: str
    rules_info: str  # JSON string from database
    is_enabled: bool
    created_by: str
    updated_by: Optional[str]
    create_time: str
    update_time: str
    
    # 扩展字段
    sop_name: Optional[str] = None
    
    class Config:
        from_attributes = True


class SOPProblemRuleQuery(BaseModel):
    """SOP问题规则查询参数"""
    search: Optional[str] = Field(None, description="搜索关键词", max_length=200)
    sop_id: Optional[str] = Field(None, description="SOP ID", max_length=100)
    is_enabled: Optional[bool] = Field(None, description="是否启用")
    page: int = Field(1, description="页码", ge=1)
    page_size: int = Field(10, description="每页大小", ge=1, le=100)


# ============ Zabbix 相关模型 ============

class ZabbixItemOption(BaseModel):
    """Zabbix监控项选项"""
    value: str = Field(..., description="监控项key")
    label: str = Field(..., description="监控项显示名称")
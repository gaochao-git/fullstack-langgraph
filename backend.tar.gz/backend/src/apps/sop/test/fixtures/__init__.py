"""
SOP模块测试fixtures
"""

from .sop_fixtures import *
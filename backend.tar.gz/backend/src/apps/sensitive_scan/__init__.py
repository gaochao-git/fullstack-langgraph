# 敏感数据扫描模块

from .endpoints import router

__all__ = ["router"]
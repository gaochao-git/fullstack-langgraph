"""
提示词管理模块，多转了一层，为了保持和官方一样的目录结构
"""
from ..agent_utils import get_system_prompt_from_db_async

# 直接使用统一的数据库获取方法（只使用异步版本）
get_system_prompt_async = get_system_prompt_from_db_async
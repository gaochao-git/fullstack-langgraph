"""
通用智能体配置模块
保留此文件是为了保持统一的目录结构，后续可能会添加特定配置
"""

# generic_agent 是模板 Agent，不需要 INIT_AGENT_CONFIG
# 因为它不会被注册到系统，agent_id 是运行时传入的
"""
Agent模块测试fixtures
"""

from .agent_fixtures import *
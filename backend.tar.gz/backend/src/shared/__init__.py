"""
Shared modules
"""
"""
全局共享测试fixtures
只包含跨模块的通用测试数据和fixture
各业务模块的专用fixtures请查看对应模块的test/fixtures/目录
"""

from .common_fixtures import *
import{o as r}from"./index-Z4Zwdkic.js";const o={async create(a){const t=await r("/api/v1/chat/threads",a);return t&&t.status==="ok"&&t.data?t.data:t}};export{o as t};

import{b as r}from"./graph-B6e1zYRb.js";var e=4;function a(o){return r(o,e)}export{a as c};

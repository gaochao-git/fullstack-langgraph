import{_ as a,$ as n}from"./ZabbixDataRenderer-CC_Zb7wE.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};

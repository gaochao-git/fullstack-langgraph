import{U as a,O as n}from"./GenericAgentWelcome-CNx-mMDU.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};

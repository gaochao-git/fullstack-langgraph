import{_ as a,$ as n}from"./ZabbixDataRenderer-COxak6fb.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};

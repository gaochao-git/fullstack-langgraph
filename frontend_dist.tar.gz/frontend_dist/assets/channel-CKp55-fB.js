import{U as a,M as n}from"./AgentChat-BWGFNjHy.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};

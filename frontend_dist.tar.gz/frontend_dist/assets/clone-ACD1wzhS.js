import{b as r}from"./graph-C3-O6FXA.js";var e=4;function a(o){return r(o,e)}export{a as c};

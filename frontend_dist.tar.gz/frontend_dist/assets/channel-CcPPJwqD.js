import{Y as a,_ as n}from"./ZabbixDataRenderer-CX5HHanC.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};

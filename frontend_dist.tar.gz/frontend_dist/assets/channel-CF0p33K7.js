import{Y as a,_ as n}from"./ZabbixDataRenderer-CM6rx9Kr.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};

import{b as r}from"./graph-C2ROjLOS.js";var e=4;function a(o){return r(o,e)}export{a as c};

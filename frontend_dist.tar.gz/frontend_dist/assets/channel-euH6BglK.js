import{Y as a,_ as n}from"./ZabbixDataRenderer-Dk9IMZn1.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};

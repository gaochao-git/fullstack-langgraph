import{Y as a,_ as n}from"./ZabbixDataRenderer-D40u05qS.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};

import{Y as a,_ as n}from"./ZabbixDataRenderer-DXKxe6MD.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};

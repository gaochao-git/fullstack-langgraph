import{a2 as o,a3 as n}from"./AgentChat-9JSN5jLL.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};

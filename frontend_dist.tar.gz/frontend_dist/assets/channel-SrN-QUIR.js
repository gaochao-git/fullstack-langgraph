import{U as a,M as n}from"./AgentChat-BtHpJuHk.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};

import{_ as a,$ as n}from"./ZabbixDataRenderer-BcHJQjli.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};

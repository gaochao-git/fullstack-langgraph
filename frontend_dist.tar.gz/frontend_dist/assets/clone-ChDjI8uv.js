import{b as r}from"./graph-Dh9p6Coe.js";var e=4;function a(o){return r(o,e)}export{a as c};
